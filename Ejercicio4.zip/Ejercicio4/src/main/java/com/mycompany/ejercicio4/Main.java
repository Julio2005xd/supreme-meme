//Julio Cesar Hernández Monroy 28/04/24
//Programa para consultar información de un empleado y modificar su salario
package com.mycompany.ejercicio4;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        char opcion;
        char opcion2;
        char opcion4;
        Scanner sc = new Scanner(System.in);
        Empleado Empleado = new Empleado ("Juan Pablo",1000000,"2022/10/02");
        do{
        System.out.println("Bienvenido, ¿desea obtener información de los empleados de la empresa? (s/n)(S/N)");
        opcion = sc.next().charAt(0);
        if (opcion == 'S' || opcion =='s') {
            System.out.println("Empleado: "+Empleado.getNombre()+", Salario: "+Empleado.getSalario()+", Fecha de contratación: "+Empleado.getFecha());
            System.out.println("¿Desea modificar el salario del empleado? (s/n)(S/N)");
        opcion2 = sc.next().charAt(0);
        if (opcion2 == 'S' || opcion2 =='s') {
            System.out.println("Por favor, digite el nuevo salario de: "+Empleado.getNombre());
            int Nsalario = sc.nextInt();
            Empleado.setSalario(Nsalario);
            System.out.println("Operación realizada, el nuevo salario de "+Empleado.getNombre()+ " es de: "+Empleado.getSalario());
        }else{
            System.out.println("Entendido, gracias por utilizar el servicio");
            System.exit(0);
        }
        }else{
            System.out.println("Entendido, gracias por utilizar el servicio");
            System.exit(0);
        }
        System.out.println("¿Desea volver a usar el servicio? (s/n)(S/N)");
        opcion4 = sc.next().charAt(0);
    }while(opcion4 == 's' || opcion4 == 'S');
    System.out.println("Entendido, gracias por utilizar el servicio");
}
}
