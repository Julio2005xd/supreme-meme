//Julio Cesar Hernández Monroy 28/04/24
//Programa para consultar información de un empleado y modificar su salario
package com.mycompany.ejercicio4;

public class Empleado {
    private String Nombre;
    private int Salario;
    private String Fecha;

    public Empleado (String Nombre, int Salario, String Fecha){
        this.Nombre = Nombre;
        this.Salario = Salario;
        this.Fecha = Fecha;
    }

    public String getNombre(){
        return Nombre;
    }

    public void setSalario(int NewSalario){
        Salario = NewSalario;
    }
    public int getSalario(){
        return Salario;
    }
    public String getFecha(){
        return Fecha;
    }

}


