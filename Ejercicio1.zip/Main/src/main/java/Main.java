//Julio Cesar Hernández Monroy 26/04/2024
//Programa para poner y mostrar nombre,edad, y 2 calificaciones de un estudiante con getter y setter

public class Main {
public static void main(String[] args){
Estudiante estudiante = new Estudiante("Juan", 20);
estudiante.setCalificacion(0, 85.0);
estudiante.setCalificacion(1, 92.5);

System.out.println("Nombre del estudiante:" + estudiante.getNombre());
System.out.println("Edad del estudiante:" + estudiante.getEdad());
System.out.println("Calificación 1:" + estudiante.getCalificacion(0));
System.out.println("Calificación 2:" + estudiante.getCalificacion(1));
}
}
