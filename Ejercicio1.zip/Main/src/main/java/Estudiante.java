//Julio Cesar Hernández Monroy 26/04/2024
//Programa para obtener y devolver nombre,edad, calificaciones de un estudiante con getter y setter

public class Estudiante {
// Atributos privados
private String nombre;
private int edad;
private double[] calificaciones;

// Constructor
public Estudiante(String nombre, int edad) {
this.nombre = nombre;
this.edad = edad;
this.calificaciones = new double[5]; // Suponemos 5 calificaciones

}

// Getter para el nombre
public String getNombre() {
return nombre;
}

// Setter para la edad
public void setEdad(int edad) {
this.edad = edad;
}

public int getEdad(){
    return edad;
}
// Getter para una calificación específica
public double getCalificacion(int indice) {
return calificaciones[indice];
}

// Setter para una calificación específica
public void setCalificacion(int indice, double calificacion) {
calificaciones[indice] = calificacion;
}
}



