// Julio Cesar Hernández Monroy 28/04/24
// Programa que sirve para hallar el area de un circulo

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Por favor, digite el radio del circulo en metros");
        int Entrada = sc.nextInt();
        Circulo circulo = new Circulo(0);
        circulo.setRadio(Entrada);
        System.out.println("El area del circulo es de: "+circulo.getArea()+" Metros cuadrados");
    }
}
