// Julio Cesar Hernández Monroy 28/04/24
// Programa que sirve para hallar el area de un circulo

public class Circulo {
    private int Radio;
    private Double Area;

    public Circulo(int Radio){
        this.Radio = Radio;
    }

    public void setRadio(int Valor){
        Radio = Valor;
    }

    public Double getArea(){
        return Area = Math.PI*(Radio*Radio);
    }

}


