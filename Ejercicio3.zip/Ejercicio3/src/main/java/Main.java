//Julio Cesar Hernández Monroy 26/4/24
//Programa que muestra el modelo, marca y velocidad actual de unos carros

public class Main {
    public static void main(String[] args){
        Automovil carro1 = new Automovil("Grand Vitara","Chevrolet");
        Automovil carro2 = new Automovil("Sandero","Renault");
        Automovil carro3 = new Automovil("Prado","Toyota");
        carro1.setVelocidad(1, 50);
        carro2.setVelocidad(2, 70);
        carro3.setVelocidad(3, 80);

        System.out.println("Modelo carro 1: "+carro1.getModelo()+", Marca carro 1: "+ carro1.getMarca()+", Velocidad actual del carro 1: "+carro1.getVelocidad(1)+" Km/h");
        System.out.println("Modelo carro 2: "+carro2.getModelo()+", Marca carro 2: "+ carro2.getMarca()+", Velocidad actual del carro 2: "+carro2.getVelocidad(2)+" Km/h");
        System.out.println("Modelo carro 3: "+carro3.getModelo()+", Marca carro 3: "+ carro3.getMarca()+", Velocidad actual del carro 3: "+carro3.getVelocidad(3)+" Km/h");
    }
}
