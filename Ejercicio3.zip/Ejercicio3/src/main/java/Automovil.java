//Julio Cesar Hernández Monroy 26/4/24
//Programa que muestra el modelo, marca y velocidad actual de unos carros

public class Automovil {
    // Atributos privados
private String Modelo;
private String Marca;
private double[] Velocidad;

// Constructor
public Automovil(String Modelo, String Marca) {
this.Modelo = Modelo;
this.Marca = Marca;
this.Velocidad = new double[4];
}
public String getModelo(){
    return Modelo;
}

public String getMarca(){
    return Marca;
}
public double getVelocidad(int NumCarro){
    return Velocidad[NumCarro];
}
public void setVelocidad(int NumCarro, double VelocidadAct){
    Velocidad[NumCarro] = VelocidadAct;
}
}
