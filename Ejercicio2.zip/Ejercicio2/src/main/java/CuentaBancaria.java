/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author EIT
 */
public class CuentaBancaria {
    // Atributos privados
private int saldo;
private int numerocuenta;

// Constructor
public CuentaBancaria(int saldo, int numerocuenta) {
this.saldo = saldo;
this.numerocuenta = numerocuenta;
}
public int getCuentaBancaria(){
    return numerocuenta;
}
public int getSaldo(){
    return saldo;
}
public void Retirar(int monto){
    if (monto>saldo){
        System.out.println("Saldo insuficiente");
    } else {
        saldo = saldo-monto;
        System.out.println("Retiro exitoso");
    }
}
public void Abonar(int monto){
    if (monto<0){
        System.out.println("Digite una cantidad de dinero positivo");
    } else {
        saldo = saldo + monto;
        System.out.println("Abono exitoso");
    }
}
}

