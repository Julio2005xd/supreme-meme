/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author EIT
 */
import java.util.Scanner;
public class Main {
    public static void main(String[] args){
     char continuar;
     Scanner sc = new Scanner(System.in);
     CuentaBancaria cuenta1 = new CuentaBancaria(100, 12345678);
     System.out.println("Bienvenido de nuevo: "+ cuenta1.getCuentaBancaria());
     do{
     System.out.println("Por favor digite una opcion");
     System.out.println("1. Consultar saldo");
     System.out.println("2. Retirar dinero de la cuenta");
     System.out.println("3. Depositar dinero en la cuenta");
     int menu = sc.nextInt();
     if (menu == 1){
         System.out.println("Consultando saldo...");
         System.out.println("El total del saldo que hay en su cuenta es de:"+cuenta1.getSaldo());
     } else if (menu == 2){
         System.out.println("¿Cuanto dinero desea retirar de su cuenta?");
         int rdinero = sc.nextInt();
         cuenta1.Retirar(rdinero);
     } else if (menu == 3){
         System.out.println("¿Cuanto dinero desea abonar en su cuenta?");
         int adinero = sc.nextInt();
         cuenta1.Abonar(adinero);
     } else {
         System.out.println("Digite un valor correcto (1,2,3)");
     }     
     System.out.println("¿Desea seguir usando el programa? (S/N)(s/n)" );
     continuar = sc.next().charAt(0);
     }while(continuar == 's'|| continuar == 'S');
    }
}
